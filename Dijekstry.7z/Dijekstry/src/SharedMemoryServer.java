import java.net.MalformedURLException;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class SharedMemoryServer extends UnicastRemoteObject implements SharedMemory {

	private int flags[];
	private int turn;
	
	protected SharedMemoryServer(int size) throws RemoteException {
		super();
		this.flags = new int[size];
		for(int i = 0; i < size; ++i) {
			this.flags[i] = 0;
		}
		this.turn = 0;
		System.out.println("Konstruktor serwera pamieci wspoldzielonej.");
	}

	private static final long serialVersionUID = 8252127657559213455L;

	@Override
	public int getValue(int p)  throws RemoteException{
		return this.flags.length;
	}
	
	public static void main(String[] args) {
		try {
			System.out.println("Server starting for " + args[0] + " processes.");
			SharedMemoryServer tre = new SharedMemoryServer(Integer.parseInt(args[0]));
			java.rmi.Naming.rebind("SERVER", tre);
			System.out.println("Server started for " + args[0] + " processes.");
		} catch (RemoteException e) {
			e.printStackTrace();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public synchronized void setFlag(int i, int value) throws RemoteException {
		this.flags[i] = value;
	}

	@Override
	public synchronized int getFlag(int i)  throws RemoteException {
		return this.flags[i];
	}

	@Override
	public synchronized void setTurn(int i) throws RemoteException {
		this.turn = i;
	}

	@Override
	public synchronized int getTurn() throws RemoteException {
		return this.turn;
	}


}
