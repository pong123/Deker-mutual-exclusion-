import java.net.MalformedURLException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.Random;

public class Process {
	
	/* 
	 * najpierw nalezy uruchpmic w jendym okienku rmiregistry
	 * potem w drugim okienku nalezy uruchomic java SharedMemoryServer 3
	 * (jako parametr wpisuje sie maksymalna ilosc procesow)
	 * potem wszystkie procesy w osobnych linijkach numerujac od zera, czyli dla trzech procesow:
	 * java Process 0
	 * java Process 1
	 * java Process 2
	 */

	public static void main(String[] args) {
		try {
			SharedMemory serwer = (SharedMemory) java.rmi.Naming.lookup("rmi://localhost/SERVER");
			int n = serwer.getValue(0);
			System.out.println("Test serwera : jest " + n + " procesow.");
			
			int p = Integer.parseInt(args[0]);
			System.out.println("Process : " + p + " started.");
			
			/* ALGORYTM DIJEKSTRY */
			Random r = new Random();
			L:
			while(true) {
				try {
					Thread.sleep(r.nextInt(2000));
				} catch (InterruptedException e) {
				}
				//System.out.println("Process " + p + " rozpoczyna algorytm.");
				serwer.setFlag(p, 1);
				int other = serwer.getTurn();
				while(other != p) {
					int test = serwer.getFlag(other);
					if(test == 0) {
						serwer.setTurn(p);
					}
					other = serwer.getTurn();
				}
				//System.out.println("Process " + p + " przechodzi do drugiej czesci algorytmu.");
				serwer.setFlag(p, 2);
				for(int k = 0; k < n; ++k) {
					if(k != p) {	
						int test = serwer.getFlag(k);
						if(test == 2) continue L;
					}
				}
				System.out.println("Process " + p + " wchodzi do sekcji krytycznej.");
				try {
					Thread.sleep(r.nextInt(1000) + 1000);
				} catch (InterruptedException e) {
				}
				System.out.println("Process " + p + " wychodzi z sekcji krytycznej.");
				serwer.setFlag(p,  0);
			}
		} catch (RemoteException e) {
			e.printStackTrace();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (NotBoundException e1) {
			e1.printStackTrace();
		}
	}

}
