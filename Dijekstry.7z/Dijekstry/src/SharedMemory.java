import java.rmi.Remote;
import java.rmi.RemoteException;

public interface SharedMemory extends Remote {

	/*
	 * do testowania serwera
	 */
	public int getValue(int p) throws RemoteException;
	
	/*
	 * do obslugi pamieci wspoldzielonej w algorytmie Dijekstry
	 */
	public void setFlag(int i, int value) throws RemoteException;
	public int getFlag(int i) throws RemoteException;
	public void setTurn(int i) throws RemoteException;
	public int getTurn() throws RemoteException;
}
